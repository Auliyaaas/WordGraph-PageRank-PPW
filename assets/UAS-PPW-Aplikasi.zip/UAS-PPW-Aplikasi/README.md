# Word Graph & PageRank dari PDF

Aplikasi Streamlit untuk analisis keterkaitan kata dan sentralitas PageRank
berbasis dokumen PDF. 

Aplikasi ini dibuat untuk memenuhi UAS pada mata kuliah Pencarian &Penambangan Web